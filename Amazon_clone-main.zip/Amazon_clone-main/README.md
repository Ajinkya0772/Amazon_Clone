# Amazon_clone
This is a Amazon App Clone with multiple functionalities like User authentication (Sign in or Login) using Firebase, Add to cart products , Payment Gateway using Stripe , Shows your order history using database in firebase and it is made using Reactjs.

Demo Images : 
<img width="960" alt="1" src="https://user-images.githubusercontent.com/93420193/174482888-76bf5199-5d96-478d-8bd7-3a251a070246.png">

<img width="960" alt="2" src="https://user-images.githubusercontent.com/93420193/174482892-011ef7c9-6b06-4e77-8fb2-1aeec42fd685.png">

<img width="960" alt="3" src="https://user-images.githubusercontent.com/93420193/174482893-00f149a9-f4b2-4b35-bc70-04d1d1f9901a.png">

<img width="960" alt="4" src="https://user-images.githubusercontent.com/93420193/174482896-b249e542-9c35-4ae7-a087-90b645d7680e.png">

<img width="960" alt="5" src="https://user-images.githubusercontent.com/93420193/174482899-22471020-baed-44fb-8b37-07b9dc299d79.png">

<img width="958" alt="6" src="https://user-images.githubusercontent.com/93420193/174482901-0870d442-eaa8-4041-a0b7-99a0c6635216.png">

<img width="960" alt="7" src="https://user-images.githubusercontent.com/93420193/174482904-8c4c9eee-3efd-4287-9c03-53f2806f9008.png">

Demo Video : 

https://user-images.githubusercontent.com/93420193/174482922-266a0be5-280c-4c9f-a1a5-90dec7ad5305.mp4

